MIRA TRAY KEEPER
================

Windows 11 can stop hiding your damn tray icons.

HOW TO INSTALL
1. Double-click MiraTrayKeeper.exe.
2. Click INSTALL + ENABLE.
3. Done. No reboot is required.

WHAT IT DOES
- Makes every current notification-area icon visible.
- Checks once per minute and promotes newly added icons automatically.
- Runs only for the current Windows user.
- Does not require administrator access.
- Does not collect data, access the internet, or run continuously.

UNINSTALL
Open MiraTrayKeeper.exe and click UNINSTALL.

Designed & built by Mira  •  Beside, always
